<?php
// listFilesProc.php
require_once 'PdoMethods.php';

// Query the database for files
$pdo = new PdoMethods();
$sql = "SELECT * FROM file_uploads ORDER BY upload_date DESC";
$results = $pdo->selectNotBinded($sql);

$output = "";

if ($results === 'error') {
    $output = "<div class='alert alert-danger'>Error: Could not retrieve files from the database.</div>";
} else {
    if (count($results) > 0) {
        $output = "<h1>List Files</h1>";
        $output .= "<p><a href='file_upload.php'>Add File</a></p>";
        $output .= "<ul>";
        
        foreach ($results as $row) {
            $output .= "<li><a href='" . $row['file_path'] . "' target='_blank'>" . htmlspecialchars($row['file_name']) . "</a></li>";
        }
        
        $output .= "</ul>";
    } else {
        $output = "<h1>List Files</h1>";
        $output .= "<p><a href='file_upload.php'>Add File</a></p>";
        $output .= "<p>No files have been uploaded yet.</p>";
    }
}
?>